# Don't add async module imports here
from .app import App  # type: ignore
