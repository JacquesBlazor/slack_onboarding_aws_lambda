from .resource import SlackAppResource
