class BoltError(Exception):
    """General class in a Bolt app"""
